Each CSV is used to populate the database table with the same name.

General notes about the data:
* I cleaned the data to only include articles which had the full information available for it (article features and metadata)
* There were repeated articles in the data. I removed duplicates (by looking at articles with the same titles), keeping the ones with the latest date published.
* I removed any sources with < 10 articles: Huffington Post Political Satire, National Report, End the Fed, Raw Story, Occupy Liberals, DC Gazette, and Xinhua were therefore removed

Notes about topSourcePhrases data:
* If a source did not have ten top phrases for a month, I put a "NULL" placeholder for the phrases it did not have
* If the source had no top phrases for a given month, it will not have a row in the topSourcePhrases table

Issues with the data:
* Facebook shares for an article may not be accurate. This is due to a redirect
of the web page's URL to the main page of the news source. Prntly is an example of this.
